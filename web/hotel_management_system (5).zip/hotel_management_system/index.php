<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hotel Management System</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<div class="container">
    <h1>Welcome to the Hotel Management System</h1>
    <p><a href="php/room_booking.php">Book a Room</a></p>
    <p><a href="php/manage_rooms.php">Manage Rooms</a></p>
</div>

</body>
</html>
