<?php
// Include the database connection
include 'db_connection.php';

// Add product
if (isset($_POST['add_product'])) {
    $product_name = $_POST['product_name'];
    $quantity = $_POST['quantity'];
    $unit = $_POST['unit'];
    $price = $_POST['price'];
    $threshold = $_POST['threshold'];
    $category = $_POST['category'];

    $sql = "INSERT INTO products (product_name, quantity, unit, price, threshold, category) 
            VALUES ('$product_name', $quantity, '$unit', $price, $threshold, '$category')";
    if ($conn->query($sql) === TRUE) {
        echo "New product added successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Delete product
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $sql = "DELETE FROM products WHERE id=$id";

    if ($conn->query($sql) === TRUE) {
        echo "Product deleted successfully";
        $sql_resequence = "
            SET @count = 0;
            UPDATE products SET id = @count:= @count + 1;
            ALTER TABLE products AUTO_INCREMENT = 1;
        ";
        $conn->multi_query($sql_resequence);
        header("Location: stockmanagement.php");
        exit();
    } else {
        echo "Error deleting product: " . $conn->error;
    }
}

// Fetch Products Based on Category
$category = isset($_GET['category']) ? $_GET['category'] : 'HNG';
$sql = "SELECT * FROM products WHERE category='$category'";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Stock Management</title>
    <style>
        /* Table styling */
        table {
            width: 80%;
            margin: 20px auto;
            border-collapse: collapse;
            font-family: Arial, sans-serif;
        }
        th, td {
            padding: 10px;
            text-align: left;
            border: 1px solid #ddd;
        }
        th {
            background-color: #f2f2f2;
        }
        tr:hover {
            background-color: #f5f5f5;
        }
        a {
            text-decoration: none;
            color: #333;
        }
        a:hover {
            text-decoration: underline;
        }
        /* Notification styling */
        #notification {
            position: fixed;
            bottom: 20px;
            right: 20px;
            background-color: #f44336;
            color: white;
            padding: 15px;
            border-radius: 5px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            display: block; /* Set to block by default so it's visible */
            z-index: 1000; /* Make sure it stays on top of other elements */
        }

        #notification .close-btn {
            margin-left: 15px;
            color: white;
            cursor: pointer;
            float: right;
        }
    </style>
</head>
<body>
<?php include 'index.php'; ?>
    <h2 style="text-align: center;">Stock Management - <?php echo $category; ?> Products</h2>

    <div style="text-align: center;">
        <a href="sales.php">Record a usage</a> |
        <a href="sales_by_date.php">View usage by Date</a> |
        <a href="low_stock_report.php">View Low Stock Report</a>
    </div><br>

    <form method="post" action="" style="width: 50%; margin: 0 auto;">
        <label for="product_name">Product Name:</label><br>
        <input type="text" id="product_name" name="product_name" required><br><br>

        <label for="quantity">Quantity:</label><br>
        <input type="number" id="quantity" name="quantity" required><br><br>

        <label for="unit">Unit of Measurement:</label><br>
        <select id="unit" name="unit" required>
            <option value="pcs">Pcs</option>
            <option value="box">Box</option>
            <option value="kg">Kg</option>
            <option value="g">Gram</option>
            <option value="liter">Liter</option>
            <option value="ml">Milliliter</option>
            <option value="pack">Pack</option>
            <option value="dozen">Dozen</option>
            <option value="set">Set</option>
            <option value="meter">Meter</option>
            <option value="cm">Centimeter</option>
            <option value="inch">Inch</option>
            <option value="yard">Yard</option>
            <option value="roll">Roll</option>
        </select><br><br>

        <label for="price">Price:</label><br>
        <input type="text" id="price" name="price" required><br><br>

        <label for="threshold">Alert Threshold:</label><br>
        <input type="number" id="threshold" name="threshold" value="10" required><br><br>

        <label for="category">Category:</label><br>
        <select id="category" name="category" required>
            <option value="HNG">HNG Products</option>
            <option value="Other">Other Products</option>
        </select><br><br>

        <input type="submit" name="add_product" value="Add Product">
    </form>

    <h2 style="text-align: center;"><?php echo $category; ?> Products</h2>
    <table>
        <tr>
            <th>ID</th>
            <th>Product Name</th>
            <th>Quantity</th>
            <th>Unit</th>
            <th>Price</th>
            <th>Actions</th>
            <th>Stock Alert</th>
        </tr>
        <?php
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row['id'] . "</td>";
                echo "<td>" . $row['product_name'] . "</td>";
                echo "<td>" . $row['quantity'] . "</td>";
                echo "<td>" . $row['unit'] . "</td>";
                echo "<td>" . $row['price'] . "</td>";
                echo "<td>
                    <a href='stockmanagement.php?delete=" . $row['id'] . "' onclick='return confirm(\"Are you sure you want to delete this product?\")'>Delete</a> | 
                    <a href='update.php?id=" . $row['id'] . "'>Update</a>
                </td>";

                // Stock alert: Check if quantity is less than or equal to threshold
                if ($row['quantity'] <= $row['threshold']) {
                    echo "<td style='color: red;'>Low Stock!</td>";
                } else {
                    echo "<td>In Stock</td>";
                }

                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='7'>No " . $category . " products found</td></tr>";
        }
        ?>
    </table>

    <div id="notification">
        <span id="notification-message">Low stock alert!</span>
        <span class="close-btn" onclick="closeNotification()">×</span>
    </div>

    <script>
        let dismissedProducts = [];

        function checkLowStock() {
            fetch('check_low_stock.php?category=<?php echo $category; ?>')
                .then(response => response.json())
                .then(data => {
                    let productsToNotify = data.filter(product => !dismissedProducts.includes(product.id));

                    if (productsToNotify.length > 0) {
                        let message = 'Low stock alert for: ';
                        productsToNotify.forEach(product => {
                            message += `${product.product_name} (Qty: ${product.quantity} ${product.unit}), `;
                        });
                        document.getElementById('notification-message').innerText = message.slice(0, -2); // Remove the last comma and space
                        document.getElementById('notification').style.display = 'block';
                    }
                });
        }

        function closeNotification() {
            fetch('check_low_stock.php?category=<?php echo $category; ?>')
                .then(response => response.json())
                .then(data => {
                     dismissedProducts = data.map(product => product.id);
                }); 
            document.getElementById('notification').style.display = 'none';
        }

        // Initially check for low stock when the page loads
        checkLowStock();

        // Continue checking every 10 seconds
        setInterval(checkLowStock, 10000); // Check every 10 seconds
    </script>
</body>
</html>

<?php
$conn->close();
